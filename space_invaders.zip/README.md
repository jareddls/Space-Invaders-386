# Space-Invaders-386
Group Members: Jared De Los Santos, Tiffany Tran


Two libraries need to be installed:\
pip install pygame\
pip install Pillow\